insert into Tasks
(Task_Name, Task_Action, Task_Start, Task_Deadline, Task_Staff, Task_Price, Task_IsPriority, Task_Department, Task_Status, Task_MainTask)
values
('Navn', 'Action', '01-01-2016', '01-01-2016', 'Personale', 0.00, 0, 0, 3, null)